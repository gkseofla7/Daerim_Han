import random
import numpy as np
import pygame
import os

pygame.init()
running = True
screen_width = 500  # 가로
screen_height = 500  # 새로
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("MonominoDomino")  # 게임 이름
current_path = os.path.dirname(__file__)  # 현재 파일의 위치를 반환
image_path = os.path.join(current_path, "images")  # images 폴더 위치 반환
background = pygame.image.load(os.path.join(image_path, "background.png"))

block_1 = pygame.image.load(os.path.join(image_path, "block_1.png"))

game_font = pygame.font.Font(None, 30)

total_time = 60

start_ticks = pygame.time.get_ticks()

class GeoObject:
    def __init__(self, x, y):
        self.obj_pos = [x, y]
        self.obj_vel = [0, 0]

    def update(self, dt):
        self.obj_pos[0] = self.obj_pos[0] + self.obj_vel[0]*dt
        self.obj_pos[1] = self.obj_pos[1] + self.obj_vel[1]*dt

    def draw(self):
        
        screen.blit(block_1, (self.obj_pos[0], self.obj_pos[1]))


class Box(GeoObject):

    def __init__(self, x, y):
        super().__init__(x, y)

    def moveLeft(self, dt):
        if self.obj_pos[0] >= 50:
            goal = self.obj_pos[0] - 50
            self.obj_vel[0] = -0.03
            while self.obj_pos[0] > goal:
                self.update(dt)
                domino.drawBackground()
                domino.drawBlue()
                domino.drawGreen()
                self.draw()
                pygame.display.update()

            self.obj_vel[0] = 0
            self.obj_pos[0] = goal

    def moveRight(self, dt):
        if self.obj_pos[0] <= 100:
            goal = self.obj_pos[0] + 50
            self.obj_vel[0] = +0.03
            while self.obj_pos[0] < goal:
                self.update(dt)
                domino.drawBackground()
                domino.drawBlue()
                domino.drawGreen()
                self.draw()
                pygame.display.update()

            self.obj_vel[0] = 0
            self.obj_pos[0] = goal

    def moveDown(self, dt):
        if self.obj_pos[1] <= 100:
            goal = self.obj_pos[1] + 50
            self.obj_vel[1] = 0.03
            while self.obj_pos[1] < goal:
                self.update(dt)
                domino.drawBackground()
                domino.drawBlue()
                domino.drawGreen()
                self.draw()
                pygame.display.update()

            self.obj_vel[1] = 0
            self.obj_pos[1] = goal

    def moveUp(self, dt):
        if self.obj_pos[1] >= 50:
            goal = self.obj_pos[1] - 50
            self.obj_vel[1] = -0.03
            while self.obj_pos[1] > goal:
                self.update(dt)
                domino.drawBackground()
                domino.drawBlue()
                domino.drawGreen()
                self.draw()
                pygame.display.update()

            self.obj_vel[1] = 0
            self.obj_pos[1] = goal

class Two_Box():
    def __init__(self):
        self.boxes = []

    def update(self, dt):
        for box in self.boxes:
            box.update(dt)

    def moveLeft(self, dt):
        if self.boxes[0].obj_pos[0] >= 50:
            goal = self.boxes[0].obj_pos[0] - 50
            goal_2 = self.boxes[1].obj_pos[0] - 50
            self.boxes[0].obj_vel[0] = -0.03
            self.boxes[1].obj_vel[0] = -0.03
            while self.boxes[0].obj_pos[0] > goal:
                self.update(dt)
                domino.drawBackground()
                domino.drawBlue()
                domino.drawGreen()

                self.boxes[0].draw()
                self.boxes[1].draw()
                pygame.display.update()

            self.boxes[0].obj_vel[0] = 0
            self.boxes[1].obj_vel[0] = 0
            self.boxes[0].obj_pos[0] = int(goal)
            self.boxes[1].obj_pos[0] = int(goal_2)

    def moveRight(self, dt):
        if self.boxes[1].obj_pos[0] <= 100:
            goal = self.boxes[1].obj_pos[0] + 50
            goal_2 = self.boxes[0].obj_pos[0] + 50
            self.boxes[0].obj_vel[0] = +0.03
            self.boxes[1].obj_vel[0] = +0.03
            while self.boxes[1].obj_pos[0] < goal:
                self.update(dt)
                domino.drawBackground()
                domino.drawBlue()
                domino.drawGreen()
                self.boxes[0].draw()
                self.boxes[1].draw()
                pygame.display.update()
            self.boxes[0].obj_vel[0] = 0
            self.boxes[1].obj_vel[0] = 0
            self.boxes[1].obj_pos[0] = int(goal)
            self.boxes[0].obj_pos[0] = int(goal_2)

    def moveDown(self, dt):
        if self.boxes[1].obj_pos[1] <= 100:
            goal = self.boxes[1].obj_pos[1] + 50
            goal_2 = self.boxes[0].obj_pos[1] + 50
            self.boxes[0].obj_vel[1] = +0.03
            self.boxes[1].obj_vel[1] = +0.03
            while self.boxes[1].obj_pos[1] < goal:
                self.update(dt)
                domino.drawBackground()
                domino.drawBlue()
                domino.drawGreen()
                self.boxes[0].draw()
                self.boxes[1].draw()
                pygame.display.update()
            self.boxes[0].obj_vel[1] = 0
            self.boxes[1].obj_vel[1] = 0
            self.boxes[1].obj_pos[1] = goal
            self.boxes[0].obj_pos[1] = goal_2

    def moveUp(self, dt):
        if self.boxes[0].obj_pos[1] >= 50:

            goal = self.boxes[0].obj_pos[1] - 50
            goal_2 = self.boxes[1].obj_pos[1] - 50
            self.boxes[0].obj_vel[1] = -0.03
            self.boxes[1].obj_vel[1] = -0.03
            while self.boxes[0].obj_pos[1] > goal:
                self.update(dt)
                domino.drawBackground()
                domino.drawBlue()

                domino.drawGreen()
                self.boxes[0].draw()
                self.boxes[1].draw()
                pygame.display.update()
            self.boxes[0].obj_vel[1] = 0
            self.boxes[1].obj_vel[1] = 0
            self.boxes[0].obj_pos[1] = goal
            self.boxes[1].obj_pos[1] = goal_2


class Domino:
    def __init__(self):
        self.local_box = []
        self.boxes = {}
        self.key_command_map = {}
        self.type = 0
        self.blue = np.zeros((4, 6))
        self.green = np.zeros((6, 4))
        self.ans = 0
        self.clock = pygame.time.Clock()
        self.screen = screen

    def drawBackground(self):
        screen.blit(background, (0, 0))

    def drawBlock(self, x, y):

        screen.blit(block_1, (x, y))

    def blue_rowtoy(self, row):
        if row == 0:
            return 0
        elif row == 1:
            return 50
        elif row == 2:
            return 100
        elif row == 3:
            return 150

    def blue_coltox(self, col):
        if col == 0:
            return 200
        elif col == 1:
            return 250
        elif col == 2:
            return 300
        elif col == 3:
            return 350
        elif col == 4:
            return 400
        elif col == 5:
            return 450

    def green_rowtoy(self, row):
        if row == 0:
            return 200
        elif row == 1:
            return 250
        elif row == 2:
            return 300
        elif row == 3:
            return 350
        elif row == 4:
            return 400
        elif row == 5:
            return 450

    def green_coltox(self, col):
        if col == 0:
            return 0
        elif col == 1:
            return 50
        elif col == 2:
            return 100
        elif col == 3:
            return 150

    def drawBlue(self):
        for i in range(4):
            for j in range(6):
                if self.blue[i][j] == 1:
                    x = self.blue_coltox(j)
                    y = self.blue_rowtoy(i)
                    self.drawBlock(x, y)

    def drawGreen(self):

        for i in range(6):
            for j in range(4):
                if self.green[i][j] == 1:
                    x = self.green_coltox(j)
                    y = self.green_rowtoy(i)
                    self.drawBlock(x, y)

    def Arrange(self):
        f = False

        for i in range(4, -1, -1):
            for_pass = False
            for j in range(4):
                if for_pass == True:
                    for_pass = False
                    continue
                tmp = self.green[i][j]
                if tmp != 0:
                    if j <= 2 and self.green[i][j] == self.green[i][j+1]:
                        if self.green[i+1][j+1] == 0 and self.green[i+1][j] == 0:
                            f = True
                            self.green[i+1][j+1] = self.green[i][j+1]
                            self.green[i+1][j] = self.green[i][j]
                            self.green[i][j+1] = 0
                            self.green[i][j] = 0
                            for_pass = True

                        else:
                            for_pass = True
                    else:
                        if self.green[i+1][j] == 0:
                            f = True
                            self.green[i+1][j] = self.green[i][j]
                            self.green[i][j] = 0
        for j in range(4, -1, -1):
            for_pass = False
            for i in range(4):
                if for_pass == True:
                    for_pass = False
                    continue

                
                tmp = self.blue[i][j]
                if tmp != 0:
                    if i <= 2 and self.blue[i+1][j] == self.blue[i][j]:
                        if self.blue[i+1][j+1] == 0 and self.blue[i][j+1] == 0:
                            f = True
                            self.blue[i+1][j+1] = self.blue[i+1][j]
                            self.blue[i][j+1] = self.blue[i][j]
                            self.blue[i+1][j] = 0
                            self.blue[i][j] = 0
                            for_pass = True
                        else:
                            for_pass = True
                    else:
                        if self.blue[i][j+1] == 0:
                            f = True
                            self.blue[i][j+1] = self.blue[i][j]
                            self.blue[i][j] = 0

       
        if f == True:
            self.Arrange()

    def Erase(self):
        
        f = False
        for j in range(2, 6, 1):
            flag = True
            for i in range(4):
                if self.blue[i][j] == 0:
                    flag = False
                    break
            if flag == True:
                f = True
                for i in range(4):
                    self.blue[i][j] = 0
                self.ans += 1

        for i in range(2, 6, 1):
            flag = True
            for j in range(4):
                if self.green[i][j] == 0:
                    flag = False
                    break
            if flag == True:
                f = True
                for j in range(4):
                    self.green[i][j] = 0

                self.ans += 1
        
        if f == True:
            self.Arrange()
            self.Erase()

    def Over(self):
        tmp = False
        f = False
        for j in range(2):
            for i in range(4):
                if self.blue[i][j] != 0:
                    f = True
                    tmp = True
                    break
                    
            if j == 0 and tmp == True:
                for i in range(4):
                    self.blue[i][4] = 0
                self.ans -=1
                tmp = False
            if j == 1 and tmp == True:
                for i in range(4):
                    self.blue[i][5] = 0
                self.ans -=1
                tmp = False
        tmp = False
        for i in range(2):
            for j in range(4):
                if self.green[i][j] != 0:
                    f = True
                    tmp = True
                    break
            if i == 0 and tmp == True:
                for j in range(4):
                    self.green[4][j] = 0
                self.ans -=1
            if i == 1 and tmp == True:
                for j in range(4):
                    self.green[5][j] = 0
                tmp = False
                self.ans -=1
        if f == True:
            self.Arrange()

    def update(self):
        dt = self.clock.tick(60)
        self.drawBackground()
        self.drawBlue()
        self.drawGreen()
        
        elapse_time = (pygame.time.get_ticks() - start_ticks) / 1000
        
        timer = game_font.render(' timer: '+str(int(total_time - elapse_time)), True, (0,0,0))
        score = game_font.render('Your score :' +str(self.ans), True, (0,0,0))
        if total_time-elapse_time <0 :
            global running
            running = False
        screen.blit(timer, (250,450))
        screen.blit(score,(250, 430))
        
        for i in self.local_box:
            i.draw()
            pygame.display.update()
        pygame.display.update()
        for event in pygame.event.get():  # 동작이 들어오는지
            if self.type == 1 and len(self.local_box) != 0:

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        self.local_box[0].moveLeft(dt)
                    elif event.key == pygame.K_RIGHT:
                        self.local_box[0].moveRight(dt)
                    elif event.key == pygame.K_UP:
                        self.local_box[0].moveUp(dt)
                    elif event.key == pygame.K_DOWN:
                        self.local_box[0].moveDown(dt)
                '''
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                        pass
                '''
            elif type != 1 and len(self.local_box) != 0:
                two_box = Two_Box()
                two_box.boxes = self.local_box

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        two_box.moveLeft(dt)
                    elif event.key == pygame.K_RIGHT:
                        two_box.moveRight(dt)
                    elif event.key == pygame.K_UP:
                        two_box.moveUp(dt)
                    elif event.key == pygame.K_DOWN:
                        two_box.moveDown(dt)

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_SPACE and len(self.local_box)==0:

                    self.type = random.randint(1, 3)

                    if self.type == 1:
                        new_Box = Box(0, 0)
                        self.local_box.append(new_Box)
                    elif self.type == 2:
                        new_Box_1 = Box(0, 0)
                        new_Box_2 = Box(50, 0)
                        self.local_box.append(new_Box_1)
                        self.local_box.append(new_Box_2)
                    elif self.type == 3:
                        new_Box_1 = Box(0, 0)
                        new_Box_2 = Box(0, 50)
                        self.local_box.append(new_Box_1)
                        self.local_box.append(new_Box_2)
                elif event.key == pygame.K_q and len(self.local_box)!=0:

                    if self.type == 1:
                        row = int(self.local_box[0].obj_pos[1])/50
                        col = int(self.local_box[0].obj_pos[0])/50
                        j = 0
                        chk_wall = False
                        for j in range(6):
                            if self.blue[int(row)][j] != 0:                         
                                chk_wall = True
                                break
                        if chk_wall == False:  
                            j = 6
                            
                        self.blue[int(row)][j-1] = 1

                        i = 0
                        chk_wall = False
                        for i in range(6):
                            if self.green[i][int(col)] != 0:
                                chk_wall = True
                                break
                        if chk_wall == False:
                            i = 6

                        self.green[i-1][int(col)] = 1
                    elif self.type == 2:
                        
                        x_0 = int(self.local_box[0].obj_pos[1])/50
                        y_0 = int(self.local_box[0].obj_pos[0])/50
                        x_1 = int(self.local_box[1].obj_pos[1])/50
                        y_1 = int(self.local_box[1].obj_pos[0])/50

                        j = 0
                        chk_wall = False
                        for j in range(6):
                            if self.blue[int(x_0)][j] != 0:
                                chk_wall = True
                                break
                        if chk_wall == False:
                            j = 6
                        self.blue[int(x_0)][j-1] = 1
                        self.blue[int(x_0)][j-2] = 1

                        i = 0
                        chk_wall = False
                        for i in range(6):
                            if self.green[i][int(y_0)] != 0:
                                chk_wall = True
                                break
                            if self.green[i][int(y_1)] != 0:
                                chk_wall = True
                                break
                        if chk_wall == False:
                            i = 6
                        self.green[i-1][int(y_0)] = 1
                        self.green[i-1][int(y_1)] = 1
                    elif self.type == 3:
                        x_0 = self.local_box[0].obj_pos[1]/50
                        y_0 = self.local_box[0].obj_pos[0]/50
                        x_1 = self.local_box[1].obj_pos[1]/50
                        y_1 = self.local_box[1].obj_pos[0]/50

                        j = 1
                        chk_wall = False
                        for j in range(1, 6, 1):
                            if self.blue[int(x_0)][j] != 0:
                                chk_wall = True
                                break
                            if self.blue[int(x_1)][j] != 0:                                
                                chk_wall = True
                                break
                        if chk_wall == False:
                            j = 6
                        self.blue[int(x_0)][j-1] = 1
                        self.blue[int(x_1)][j-1] = 1

                        i = 0
                        chk_wall = False
                        for i in range(6):
                            if(self.green[i][int(y_0)] != 0):                                
                                chk_wall = True
                                break

                        if chk_wall == False:
                            i = 6

                        self.green[i-1][int(y_0)] = 1
                        self.green[i-2][int(y_0)] = 1
                        
                    self.Erase()
                    self.Over()

                    '''self.Arrange()'''
                   
                    

                    self.local_box = []


domino = Domino()

while(running):
    domino.update()

